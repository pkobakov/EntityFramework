﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=SoftJail;Trusted_Connection=True";
    }
}
