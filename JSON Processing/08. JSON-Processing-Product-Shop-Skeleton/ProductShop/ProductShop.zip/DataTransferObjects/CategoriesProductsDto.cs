﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DataTransferObjects
{
    public class CategoriesProductsDto
    {
        public int CategoryId { get; set; }
        public int ProductId { get; set; }
    }
}
